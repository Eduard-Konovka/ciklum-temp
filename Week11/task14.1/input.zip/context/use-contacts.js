import { createContext } from "react";

export const ContactsProvider = createContext();
