import { createContext } from "react";

export const contactsContext = createContext();

export const ContactsProvider = contactsContext.Provider;
