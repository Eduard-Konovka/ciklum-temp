import { useState } from "react";
import { UserProvider } from "./context/use-user";
import { ContactsProvider } from "./context/use-contacts";
import Footer from "./components/Footer";
import Header from "./components/Header";
import "./App.css";

const userData = {
  name: "Brendan",
  surname: "Eich",
  avatar: "../../../misc/avatar.png",
};
const contacts = {
  headerTel: "+380123456789",
  footerTel: "+389876543210",
  email: "test@test.com",
};

export default function App() {
  const [contactData, setContactData] = useState(contacts);
  const [email, setEmail] = useState("");

  const changeMailHandler = () => {
    setContactData({ ...contactData, email });
  };

  return (
    <>
      <UserProvider.Provider value={userData}>
        <ContactsProvider.Provider value={contactData}>
          <Header />
        </ContactsProvider.Provider>
      </UserProvider.Provider>
      <hr />
      <main className="main">
        <h2>Main Content</h2>
        <div className="row">
          <input
            className="form-control"
            type="text"
            placeholder="Введіть нову електронну пошту"
            aria-label="change email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
          <button className="btn btn-primary" onClick={changeMailHandler}>
            Змінити електронну пошту
          </button>
        </div>
      </main>
      <hr />
      <UserProvider.Provider value={userData}>
        <ContactsProvider.Provider value={contactData}>
          <Footer />
        </ContactsProvider.Provider>
      </UserProvider.Provider>
    </>
  );
}
